const functions = require("firebase-functions");
// Expressの読み込み
const express = require("express");
const requestPromise = require("request-promise-native");

// http://localhost:5000/chatoworkapi/us-central1/helloWorld



const postChatworkMessage = require('post-chatwork-message')
const CHATWORK_API_KEY = '635bdebf556fa87e5efa8f4a7b2e7bda'
const roomId = '38406786'
 
postChatworkMessage(CHATWORK_API_KEY, roomId, 'こんにちは, World')